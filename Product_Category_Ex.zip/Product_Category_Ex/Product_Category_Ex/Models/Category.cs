﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Product_Category_Ex.Models
{
    public class Category
    {
        [Key]

        [ScaffoldColumn(true)]

       public int CategoryId { get; set; }

        public string CategoryName { get; set; }

        public int ProductId { get; set; }

        public virtual Product pd { get; set; }
    }
}